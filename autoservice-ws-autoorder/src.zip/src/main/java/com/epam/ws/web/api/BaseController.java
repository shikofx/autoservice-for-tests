package com.epam.ws.web.api;

public class BaseController {

}
