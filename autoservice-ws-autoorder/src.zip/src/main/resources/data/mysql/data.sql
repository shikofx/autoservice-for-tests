insert into autoservice.auto_order (order_date, owner_name) values ('2019-04-30', 'Mike');
insert into autoservice.auto_order (order_date, owner_name) values ('2019-05-24', 'Sam');
insert into autoservice.auto_order (order_date, owner_name) values ('2019-05-10', 'James');